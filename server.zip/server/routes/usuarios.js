const express = require('express');
const router = express.Router();
const Usuario = require('../models/Usuario');

// Crear un usuario
router.post('/', async (req, res) => {
  try {
    const nuevoUsuario = new Usuario(req.body);
    await nuevoUsuario.save();
    res.status(201).json(nuevoUsuario);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Obtener todos los usuarios
router.get('/', async (req, res) => {
  const usuarios = await Usuario.find();
  res.json(usuarios);
});

// Obtener usuario por ID
router.get('/:id', async (req, res) => {
  try {
    const usuario = await Usuario.findById(req.params.id);
    if (!usuario) return res.status(404).json({ error: "No encontrado" });
    res.json(usuario);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Actualizar usuario por ID
router.put('/:id', async (req, res) => {
  try {
    const actualizado = await Usuario.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(actualizado);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Eliminar usuario por ID
router.delete('/:id', async (req, res) => {
  await Usuario.findByIdAndDelete(req.params.id);
  res.json({ mensaje: 'Eliminado correctamente' });
});

// Crear usuarios masivamente
router.post('/masivo', async (req, res) => {
  try {
    const usuarios = await Usuario.insertMany(req.body);
    res.status(201).json(usuarios);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Eliminar todos los usuarios
router.delete('/masivo', async (req, res) => {
  try {
    await Usuario.deleteMany({});
    res.json({ mensaje: 'Todos los usuarios han sido eliminados' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;